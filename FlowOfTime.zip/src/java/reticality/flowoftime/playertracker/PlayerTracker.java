package reticality.flowoftime.playertracker;

/* import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.gameevent.PlayerEvent; */

public class PlayerTracker /* extends PlayerEvent */ {

	/* public PlayerTracker (EntityPlayer player) {
		super(player);
	} */
}
